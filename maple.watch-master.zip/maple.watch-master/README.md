# maple.watch
Server status and latency check for MapleStory

This website is a copy of the original [maple.watch](https://github.com/450/maple.watch) with updated websites and server IP addresses.

GMS and EMS are most likely to be updated.
CMS and CMST server information was contributed by HikariCalyx.
MapleSEA information was contributed by Northbadge.
Other servers will be added if server information is found or contributed.

=======

See it live [here.](https://xymu.github.io/maple.watch)
